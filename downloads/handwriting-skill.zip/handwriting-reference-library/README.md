# Handwriting skill

Load SKILL.md into a suitable image-capable LLM host. Read HOST.md only when extracting crops, maintaining files or coordinating OCR. No provider or API is required by the instructions. Optional examples, tools, tests and research records are linked online rather than bundled. Links point to repository resources; the reading instructions are unchanged. Recognition gains from the revised final-verification rule have not been measured.
